// Node.js Google Translate sample application by Jukka Ruponen / IBM

var express = require('express');
var app = express();

//var appInfo = JSON.parse(process.env.VCAP_APPLICATION || "{}");
//var services = JSON.parse(process.env.VCAP_SERVICES || "{}");
var host = (process.env.VCAP_APP_HOST || 'localhost');
var port = (process.env.VCAP_APP_PORT || 80);
var outPort = (process.env.VCAP_APP_PORT || 1880);
var request = require('request');

var translate = require('@google-cloud/translate')({
  key: '<your googley key here>'
});

var remoteAddress = '';
var bodyParser = require('body-parser');

console.log('USAGE INSTRUCTIONS:');
console.log('1. Make POST request at <this host>/translate containing JSON object:');
console.log('   { lang:\"fi\", text:\"Jotain tekstiä\", host:\"<your host>\" }');
console.log('2. Take POST requst at <your host>/translated containing JSON object:');
console.log('   { lang:\"en\", text:\"Some text\" }');


app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies

app.post("/translate", function (req, res) {
//    remoteAddress = req.socket.remoteAddress;
//    if (req.socket.remoteFamily == 'IPv6') {
//      remoteAddress = remoteAddress.replace(/^.*:/, '');
//    }
    console.log('DEBUG: Got POST request from: %s', remoteAddress);
    console.log('DEBUG: Received body: %s',JSON.stringify(req.body));
    var lang = req.body.lang;
    console.log('DEBUG: Received key lang: %s', lang);
    var text = req.body.text;
    console.log('DEBUG: Received key text: %s', text);
    remoteAddress = req.body.host;
    console.log('DEBUG: Received key host: %s', remoteAddress);

    translateText(text, 'en');
    res.sendStatus(200);
    //res.end(JSON.stringify(data));
});

function translateText(fromText, toLang) {

  var translation = '';
  translate.translate(fromText, toLang, function(err, translation) {
    if (!err) {
       console.log('DEBUG: Translated to lang: %s', toLang);
       console.log('DEBUG: Translated to text: %s', translation);
       post(translation, 'en');
    }
  });
  return translation;
}

function post(toText, toLang){

  postAddress = 'http://' + remoteAddress + '/translated';
  request.post(
      postAddress,
      { json: { lang: toLang, text: toText } },
      function (error, response, body) {
          if (!error && response.statusCode == 200) {
              console.log(body)
          }
      }
  );
  console.log('DEBUG: Sent POST request to: %s', postAddress);
}

//server.listen(80);
//server.on('request', app);
//server.listen(port, function() { console.log('Listening on ' + server.address().port) });

app.listen(port);
console.log('Listening on port ' + port);
/*
app.listen = function(){
  var server = http.createServer(this);
  console.log('Listening on ' + server.address().port);
};
*/
